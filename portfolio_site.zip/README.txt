
Portfolio site for Anshika Krishnatray
-------------------------------------
Files:
- index.html
- style.css
- script.js
Resume included as: /mnt/data/anshika_resume.pdf

To publish on GitHub Pages:
1. Create repo named: your-username.github.io
2. Upload all files at the repository root
3. Commit and visit: https://your-username.github.io
